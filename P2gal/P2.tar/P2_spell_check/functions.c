#define _POSIX_C_SOURCE 200809L   // Enables POSIX functions like dprintf(), opendir(), etc.
#include "spell.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <limits.h>
#include <errno.h>

char **dict = NULL;
size_t dict_size = 0;
const char *suffix = ".txt";
int any_error = 0;

void tolower_str(char *s) {
    for (; *s; s++) *s = tolower((unsigned char)*s);
}

int cmp_words(const void *a, const void *b) {
    return strcmp(*(char **)a, *(char **)b);
}

int ends_with(const char *s, const char *end) {
    size_t n = strlen(s), m = strlen(end);
    return n >= m && strcmp(s + n - m, end) == 0;
}

void load_dict(const char *path) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        dprintf(STDERR_FILENO, "Cannot open dictionary %s: %s\n", path, strerror(errno));
        exit(EXIT_FAILURE);
    }

    dict = malloc(MAX_WORDS * sizeof(char *));
    if (!dict) {
        dprintf(STDERR_FILENO, "Memory allocation failed\n");
        close(fd);
        exit(EXIT_FAILURE);
    }

    char buf[BUF_SIZE], word[MAX_WORD_LEN];
    ssize_t n;
    int wlen = 0;

    while ((n = read(fd, buf, BUF_SIZE)) > 0) {
        for (ssize_t i = 0; i < n; i++) {
            if (buf[i] == '\n' || buf[i] == '\r') {
                if (wlen > 0) {
                    word[wlen] = '\0';
                    tolower_str(word);
                    dict[dict_size++] = strdup(word);
                    wlen = 0;
                }
            } else if (wlen < MAX_WORD_LEN - 1) {
                word[wlen++] = buf[i];
            }
        }
    }

    // handle last word in file (if it doesn’t end with newline)
    if (wlen > 0) {
        word[wlen] = '\0';
        tolower_str(word);
        dict[dict_size++] = strdup(word);
    }

    close(fd);
    qsort(dict, dict_size, sizeof(char *), cmp_words); // sorted for binary search lookup
}

int in_dict(const char *word) {
    char *key = strdup(word);
    tolower_str(key);
    char *p = key;
    void *res = bsearch(&p, dict, dict_size, sizeof(char *), cmp_words);
    free(key);
    return res != NULL;
}

int only_symbols(const char *s) {
    for (; *s; s++) if (isalpha((unsigned char)*s)) return 0;
    return 1;
}

void check_file(const char *filename, int print_name) {
    int fd = open(filename, O_RDONLY);
    if (fd < 0) {
        dprintf(STDERR_FILENO, "Cannot open file %s: %s\n", filename, strerror(errno));
        any_error = 1;
        return;
    }

    char buf[BUF_SIZE], word[MAX_WORD_LEN];
    ssize_t n;
    int wlen = 0, line = 1, col = 1, start = 1;

    // manually parse every char to detect word boundaries and keep track of positions
    while ((n = read(fd, buf, BUF_SIZE)) > 0) {
        for (ssize_t i = 0; i < n; i++, col++) {
            char c = buf[i];

            // valid word characters: letters, numbers, '-', and apostrophe (if not first)
            if (isalnum((unsigned char)c) || c == '-' || (c == '\'' && wlen > 0)) {
                if (wlen == 0) start = col;  // mark start of word
                if (wlen < MAX_WORD_LEN - 1) word[wlen++] = c;
            } else {
                // hitting punctuation or space ends a word
                if (wlen > 0) {
                    word[wlen] = '\0';
                    // check word only if it contains letters (not symbols/numbers only)
                    if (!in_dict(word) && !only_symbols(word)) {
                        if (print_name)
                            dprintf(STDOUT_FILENO, "%s:%d:%d %s\n", filename, line, start, word);
                        else
                            dprintf(STDOUT_FILENO, "%d:%d %s\n", line, start, word);
                        any_error = 1;
                    }
                    wlen = 0; // reset buffer
                }
                // update line number for newlines
                if (c == '\n') {
                    line++;
                    col = 0;
                }
            }
        }
    }

    // check last word in file if it wasn’t followed by punctuation/newline
    if (wlen > 0) {
        word[wlen] = '\0';
        if (!in_dict(word) && !only_symbols(word)) {
            if (print_name)
                dprintf(STDOUT_FILENO, "%s:%d:%d %s\n", filename, line, start, word);
            else
                dprintf(STDOUT_FILENO, "%d:%d %s\n", line, start, word);
            any_error = 1;
        }
    }

    close(fd);
}

void traverse(const char *path) {
    DIR *d = opendir(path);
    if (!d) {
        dprintf(STDERR_FILENO, "Cannot open directory %s: %s\n", path, strerror(errno));
        any_error = 1;
        return;
    }

    struct dirent *ent;
    while ((ent = readdir(d))) {
        if (ent->d_name[0] == '.') continue;  // skip hidden files/dirs (starting with '.')

        char full[PATH_MAX];
        snprintf(full, sizeof(full), "%s/%s", path, ent->d_name);

        struct stat st;
        if (stat(full, &st) != 0) {
            dprintf(STDERR_FILENO, "Cannot stat %s: %s\n", full, strerror(errno));
            any_error = 1;
            continue;
        }

        // recursively go into subdirectories
        if (S_ISDIR(st.st_mode))
            traverse(full);

        // only check regular files that match the required suffix (.txt by default)
        else if (S_ISREG(st.st_mode) && ends_with(ent->d_name, suffix))
            check_file(full, 1);
    }

    closedir(d);
}
