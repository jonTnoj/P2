#ifndef SPELL_H
#define SPELL_H

#include <stddef.h>  // for size_t


#define BUF_SIZE 4096 // limits read size per chunk for safety
#define MAX_WORD_LEN 128 // prevents word buffer overflow
#define MAX_WORDS 200000 // caps total dictionary entries

extern char **dict;
extern size_t dict_size;
extern const char *suffix;
extern int any_error;

void tolower_str(char *s);
int cmp_words(const void *a, const void *b);
int ends_with(const char *s, const char *end);

void load_dict(const char *path);
int in_dict(const char *word);

int only_symbols(const char *s);
void check_file(const char *filename, int print_name);

void traverse(const char *path);

#endif // SPELL_H
