#define _POSIX_C_SOURCE 200809L
#include "spell.h"
#include <sys/stat.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        dprintf(STDERR_FILENO, "Usage: spell [-s suffix] dict [files...]\n");
        return EXIT_FAILURE;
    }

    int arg = 1;

if (argc > 1 && strcmp(argv[1], "-s") == 0) {
    if (argc < 4) {
        dprintf(STDERR_FILENO, "Error: -s requires a suffix and a dictionary file\n");
        return EXIT_FAILURE;
    }
    if (argv[2][0] != '.') {
        dprintf(STDERR_FILENO, "Error: invalid suffix '%s' (must start with a dot)\n", argv[2]);
        return EXIT_FAILURE;
    }
    suffix = argv[2];
    arg = 3;
} 
else {
    // check if -s appears anywhere else (NOT as argv[1])
    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "-s") == 0) {
            dprintf(STDERR_FILENO, "Error: -s must appear before dictionary file\n");
            return EXIT_FAILURE;
        }
    }
    arg = 1;
}



    if (arg >= argc) {
        dprintf(STDERR_FILENO, "Error: missing dictionary file\n");
        return EXIT_FAILURE;
    }

    const char *dictfile = argv[arg++];
    load_dict(dictfile);

    if (arg == argc) {
        check_file("/dev/stdin", 0);
    } else {
        int single_file = (argc - arg == 1);
        for (; arg < argc; arg++) {
            struct stat st;
            if (stat(argv[arg], &st) != 0) {
                dprintf(STDERR_FILENO, "Cannot access %s: %s\n", argv[arg], strerror(errno));
                any_error = 1;
                continue;
            }
            if (S_ISDIR(st.st_mode))
                traverse(argv[arg]);
            else if (S_ISREG(st.st_mode))
                check_file(argv[arg], !single_file);
        }
    }

    for (size_t i = 0; i < dict_size; i++) free(dict[i]);
    free(dict);

    return any_error ? EXIT_FAILURE : EXIT_SUCCESS;
}
