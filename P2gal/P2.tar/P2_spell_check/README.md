CS 214 – Fall 2025

Project II: Spelling Checker

Authors:
Gal Nissan (gn211)
Jonathan Talmor (jt1435)

Overview
------------------------
This project implements a command-line spelling checker called spell, which reads a dictionary file and checks one or more input files or directories for words not found in that dictionary. 

spell.c – Manages command-line arguments, validates the optional -s flag, loads the dictionary, and coordinates file or directory checking.
functions.c – Implements the core logic for loading the dictionary, reading files, verifying words, and recursively scanning directories.
spell.h – Declares shared constants, global variables, and function prototypes used throughout the program.

The program defines _POSIX_C_SOURCE 200809L to ensure access to POSIX system calls such as dprintf() and directory-handling functions.
The constants BUF_SIZE, MAX_WORD_LEN, and MAX_WORDS (max dictionary size) are set to fixed limits to prevent buffer overflows and excessive memory use.

Program Usage
------------------------
To compile:
make

Usage:
spell [-s suffix] dict [files or directories]

Arguments:
dict – Path to a dictionary file containing one word per line.
files/directories – One or more text files or directories to check.
-s suffix – Optional flag that specifies which file extensions to check when traversing directories.
Default suffix: .txt

Examples:
./spell dict.txt file1.txt file2.txt
./spell -s .log words_dict.txt logs/
./spell my_dict.txt data_dir

If no files or directories are given, the program reads text from standard input.


Testing and Validation
------------------------
Basic Functionality -
We began by testing simple cases using a small dictionary file containing words like “apple”, “banana”, and “pear”. We created text files with a mix of valid and misspelled words to confirm that the program correctly identifies and prints only the misspelled ones. Each reported word included the correct line and column numbers, which verified that position tracking worked as expected.

Recursive Traversal -
To validate directory traversal, we created nested folders containing .txt files at multiple levels. The program correctly traversed subdirectories, skipped hidden files and folders beginning with a period, and only checked files ending with the specified suffix. Mixed file types were used to confirm that non-matching files were ignored. The recursion stopped properly without infinite loops or redundant checks.

Optional Flag Handling -
We tested the optional -s flag with different suffix values, as well as cases where it appeared incorrectly at the end of the command line. The program correctly required a suffix to follow the -s flag and rejected invalid usage with a clear error message. We also tested multiple -s flags in one command, and the final suffix was used as intended.

Hidden Directory Handling - 
We tested how the program handles hidden folders to confirm correct traversal behavior. Running ./spell -s .sample master_dictionary.txt .git successfully scanned .sample files inside the hidden .git directory, since it was explicitly provided as an argument. In contrast, running ./spell -s .sample master_dictionary.txt . produced no output, confirming that hidden directories (like .git) are properly skipped during normal recursive traversal.

Standard Input Mode -
Finally, we tested the mode where no input files are given, meaning the program reads from standard input. We ran spell dict.txt and typed text directly into the terminal, confirming that misspelled words were detected and printed in the simplified “line:column word” format (without filenames). This validated correct input handling for both regular files and stdin streams.


